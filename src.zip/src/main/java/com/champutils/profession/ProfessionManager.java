package com.champutils.profession;

import com.champutils.profile.PlayerProfileManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class ProfessionManager {

    private static final Map<UUID, ProfessionDataManager.ProfessionData> CACHE =
            new HashMap<>();

    private static final Set<UUID> DIRTY_PLAYERS =
            new HashSet<>();

    public static ProfessionDataManager.ProfessionData getData(
            ServerPlayer player
    ) {
        UUID uuid = PlayerProfileManager.activeProfileId(player);

        if (CACHE.containsKey(uuid)) {
            return CACHE.get(uuid);
        }

        ProfessionDataManager.ProfessionData data =
                ProfessionDataManager.load(
                        uuid,
                        player.getName().getString()
                );

        CACHE.put(uuid, data);

        return data;
    }

    private static boolean requiresProfessionTool(ProfessionType profession) {
        return profession == ProfessionType.MINING || profession == ProfessionType.FORESTRY || profession == ProfessionType.FARMING;
    }

    private static boolean hasUsableProfessionTool(ServerPlayer player, ProfessionType profession) {
        if (player == null || profession == null) return false;
        ItemStack main = player.getMainHandItem();
        if (ProfessionToolUtil.isUsableProfessionTool(player, main, profession)) return true;
        ItemStack off = player.getOffhandItem();
        return ProfessionToolUtil.isUsableProfessionTool(player, off, profession);
    }

    public static void addXp(
            ServerPlayer player,
            ProfessionType profession,
            int amount
    ) {
        if (player == null || profession == null || amount <= 0) {
            return;
        }

        if (requiresProfessionTool(profession) && !hasUsableProfessionTool(player, profession)) {
            return;
        }

        amount = ProfessionXpBoostManager.applyBoosts(
                player,
                profession,
                amount
        );

        ProfessionDataManager.ProfessionData data =
                getData(player);

        String key =
                profession.name();

        int currentXp =
                data.xp.getOrDefault(
                        key,
                        0
                );

        int currentLevel =
                data.levels.getOrDefault(
                        key,
                        1
                );

        currentXp += amount;

        data.xp.put(
                key,
                currentXp
        );

        ProfessionActionBarManager.sendXpMessage(
                player,
                profession,
                amount
        );

        while (
                currentXp >= xpRequired(currentLevel)
        ) {
            currentXp -=
                    xpRequired(currentLevel);

            currentLevel++;

            data.levels.put(
                    key,
                    currentLevel
            );

            ProfessionActionBarManager.sendLevelUpMessage(
                    player,
                    profession,
                    currentLevel
            );

            com.champutils.worldfirst.WorldFirstManager.handleProfessionLevel(
                    player,
                    profession,
                    currentLevel
            );

            com.champutils.cosmetic.TitleRegistry.handleProfessionLevel(
                    player,
                    profession,
                    currentLevel
            );
        }

        data.xp.put(
                key,
                currentXp
        );

        markDirty(
                PlayerProfileManager.activeProfileId(player)
        );
    }

    public static int xpRequired(
            int level
    ) {
        return 100 + (level * 25);
    }

    public static int getLevel(
            ServerPlayer player,
            ProfessionType profession
    ) {
        return getData(player)
                .levels
                .getOrDefault(
                        profession.name(),
                        1
                );
    }

    public static int getXp(
            ServerPlayer player,
            ProfessionType profession
    ) {
        return getData(player)
                .xp
                .getOrDefault(
                        profession.name(),
                        0
                );
    }



    public static int getFragments(
            ServerPlayer player,
            String fragmentKey
    ) {
        if (player == null || fragmentKey == null || fragmentKey.isBlank()) {
            return 0;
        }

        String normalizedFragmentKey = ProfessionWeaponFragmentConfig.normalizeRarity(fragmentKey);

        return getData(player)
                .fragments
                .getOrDefault(
                        normalizedFragmentKey,
                        0
                );
    }

    public static void addFragments(
            ServerPlayer player,
            String fragmentKey,
            int amount
    ) {
        if (player == null || fragmentKey == null || fragmentKey.isBlank() || amount <= 0) {
            return;
        }

        String normalizedFragmentKey = ProfessionWeaponFragmentConfig.normalizeRarity(fragmentKey);

        ProfessionDataManager.ProfessionData data =
                getData(player);

        int current =
                data.fragments.getOrDefault(
                        normalizedFragmentKey,
                        0
                );

        data.fragments.put(
                normalizedFragmentKey,
                current + amount
        );

        markDirty(
                PlayerProfileManager.activeProfileId(player)
        );
    }

    public static boolean removeFragments(
            ServerPlayer player,
            String fragmentKey,
            int amount
    ) {
        if (player == null || fragmentKey == null || fragmentKey.isBlank() || amount <= 0) {
            return false;
        }

        String normalizedFragmentKey = ProfessionWeaponFragmentConfig.normalizeRarity(fragmentKey);

        ProfessionDataManager.ProfessionData data =
                getData(player);

        int current =
                data.fragments.getOrDefault(
                        normalizedFragmentKey,
                        0
                );

        if (current < amount) {
            return false;
        }

        data.fragments.put(
                normalizedFragmentKey,
                current - amount
        );

        markDirty(
                PlayerProfileManager.activeProfileId(player)
        );

        return true;
    }

    private static void markDirty(
            UUID uuid
    ) {
        DIRTY_PLAYERS.add(uuid);
    }

    public static void savePlayer(
            ServerPlayer player
    ) {
        UUID uuid =
                PlayerProfileManager.activeProfileId(player);

        if (!DIRTY_PLAYERS.contains(uuid)) {
            return;
        }

        ProfessionDataManager.ProfessionData data =
                CACHE.get(uuid);

        if (data == null) {
            return;
        }

        ProfessionDataManager.save(
                uuid,
                data
        );

        DIRTY_PLAYERS.remove(uuid);
    }

    public static void saveAll() {
        for (UUID uuid : DIRTY_PLAYERS) {

            ProfessionDataManager.ProfessionData data =
                    CACHE.get(uuid);

            if (data == null) {
                continue;
            }

            ProfessionDataManager.save(
                    uuid,
                    data
            );
        }

        DIRTY_PLAYERS.clear();
    }

    public static void unloadPlayer(
            ServerPlayer player
    ) {
        savePlayer(player);

        CACHE.remove(
                PlayerProfileManager.activeProfileId(player)
        );

        ProfessionXpBoostManager.clearFractionBank(player);
    }
}
