package com.champutils.profession;

import eu.pb4.polymer.core.api.item.PolymerItem;

import com.champutils.profession.passives.DurabilitySavePassive;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class ProfessionToolManager {

    private static final int UNIDENTIFIED_PICKAXE_MODEL_DATA = 9901;
    private static final int UNIDENTIFIED_AXE_MODEL_DATA = 9902;
    private static final int UNIDENTIFIED_HOE_MODEL_DATA = 9903;
    private static final int UNIDENTIFIED_SWORD_MODEL_DATA = 9904;
    private static final int UNIDENTIFIED_SHOVEL_MODEL_DATA = 9905;

    private static final int UNIDENTIFIED_PICKAXE_COMMON_MODEL_DATA = 9911;
    private static final int UNIDENTIFIED_PICKAXE_UNCOMMON_MODEL_DATA = 9912;
    private static final int UNIDENTIFIED_PICKAXE_RARE_MODEL_DATA = 9913;
    private static final int UNIDENTIFIED_PICKAXE_EPIC_MODEL_DATA = 9914;
    private static final int UNIDENTIFIED_PICKAXE_LEGENDARY_MODEL_DATA = 9915;
    private static final int UNIDENTIFIED_PICKAXE_MYTHIC_MODEL_DATA = 9916;

    private static final int UNIDENTIFIED_AXE_COMMON_MODEL_DATA = 9921;
    private static final int UNIDENTIFIED_AXE_UNCOMMON_MODEL_DATA = 9922;
    private static final int UNIDENTIFIED_AXE_RARE_MODEL_DATA = 9923;
    private static final int UNIDENTIFIED_AXE_EPIC_MODEL_DATA = 9924;
    private static final int UNIDENTIFIED_AXE_LEGENDARY_MODEL_DATA = 9925;
    private static final int UNIDENTIFIED_AXE_MYTHIC_MODEL_DATA = 9926;

    private static final int UNIDENTIFIED_HOE_COMMON_MODEL_DATA = 9931;
    private static final int UNIDENTIFIED_HOE_UNCOMMON_MODEL_DATA = 9932;
    private static final int UNIDENTIFIED_HOE_RARE_MODEL_DATA = 9933;
    private static final int UNIDENTIFIED_HOE_EPIC_MODEL_DATA = 9934;
    private static final int UNIDENTIFIED_HOE_LEGENDARY_MODEL_DATA = 9935;
    private static final int UNIDENTIFIED_HOE_MYTHIC_MODEL_DATA = 9936;

    private static final int UNIDENTIFIED_SWORD_COMMON_MODEL_DATA = 9941;
    private static final int UNIDENTIFIED_SWORD_UNCOMMON_MODEL_DATA = 9942;
    private static final int UNIDENTIFIED_SWORD_RARE_MODEL_DATA = 9943;
    private static final int UNIDENTIFIED_SWORD_EPIC_MODEL_DATA = 9944;
    private static final int UNIDENTIFIED_SWORD_LEGENDARY_MODEL_DATA = 9945;
    private static final int UNIDENTIFIED_SWORD_MYTHIC_MODEL_DATA = 9946;

    private static final int UNIDENTIFIED_SHOVEL_COMMON_MODEL_DATA = 9951;
    private static final int UNIDENTIFIED_SHOVEL_UNCOMMON_MODEL_DATA = 9952;
    private static final int UNIDENTIFIED_SHOVEL_RARE_MODEL_DATA = 9953;
    private static final int UNIDENTIFIED_SHOVEL_EPIC_MODEL_DATA = 9954;
    private static final int UNIDENTIFIED_SHOVEL_LEGENDARY_MODEL_DATA = 9955;
    private static final int UNIDENTIFIED_SHOVEL_MYTHIC_MODEL_DATA = 9956;

    private static final Map<String, Item> REGISTERED_TOOLS =
            new HashMap<>();

    public static void registerTools() {

        REGISTERED_TOOLS.clear();

        for (
                Map.Entry<String, ProfessionToolConfig.ToolData> entry :
                ProfessionToolConfig.TOOLS.entrySet()
        ) {
            registerTool(
                    entry.getKey(),
                    entry.getValue()
            );
        }

        System.out.println(
                "[ChampUtils] Registered " +
                        REGISTERED_TOOLS.size() +
                        " profession tools."
        );
    }

    private static void registerTool(
            String toolId,
            ProfessionToolConfig.ToolData toolData
    ) {

        if (
                toolData == null ||
                        toolData.baseItem == null ||
                        toolData.baseItem.isBlank()
        ) {
            System.out.println(
                    "[ChampUtils] Invalid config for tool: " +
                            toolId
            );
            return;
        }

        ResourceLocation resourceLocation;

        try {
            resourceLocation =
                    ResourceLocation.parse(
                            toolData.baseItem
                    );
        } catch (Exception e) {
            System.out.println(
                    "[ChampUtils] Invalid item id for tool: " +
                            toolId +
                            " -> " +
                            toolData.baseItem
            );
            return;
        }

        Item baseItem =
                BuiltInRegistries.ITEM.get(
                        resourceLocation
                );

        if (baseItem == Items.AIR) {
            System.out.println(
                    "[ChampUtils] Invalid base item for tool: " +
                            toolId +
                            " -> " +
                            toolData.baseItem
            );
            return;
        }

        Item customTool =
                createProperToolType(
                        toolData,
                        baseItem
                );

        if (customTool == null) {
            System.out.println(
                    "[ChampUtils] Failed to create tool: " +
                            toolId
            );
            return;
        }

        try {

            Registry.register(
                    BuiltInRegistries.ITEM,
                    ResourceLocation.fromNamespaceAndPath(
                            "champutils",
                            toolId
                    ),
                    customTool
            );

            REGISTERED_TOOLS.put(
                    toolId,
                    customTool
            );

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Item createProperToolType(
            ProfessionToolConfig.ToolData toolData,
            Item baseItem
    ) {

        String base =
                toolData.baseItem == null
                        ? ""
                        : toolData.baseItem.toLowerCase();

        int configuredDurability =
                getBaseMaxDurability(
                        toolData,
                        baseItem
                );

        Item.Properties properties =
                new Item.Properties()
                        .stacksTo(1)
                        .durability(
                                Math.max(
                                        1,
                                        configuredDurability
                                )
                        )
                        .rarity(
                                getRarity(
                                        toolData.rarity
                                )
                        )
                        .attributes(
                                createToolCombatAttributes(
                                        toolData,
                                        base
                                )
                        );

        Tier configuredTier =
                getConfiguredTier(
                        toolData
                );

        if (base.contains("pickaxe")) {
            return new CustomPickaxeItem(
                    baseItem,
                    configuredTier,
                    properties
            );
        }

        if (base.contains("axe")) {
            return new CustomAxeItem(
                    baseItem,
                    configuredTier,
                    properties
            );
        }

        if (base.contains("hoe")) {
            return new CustomHoeItem(
                    baseItem,
                    configuredTier,
                    properties
            );
        }

        if (base.contains("shovel")) {
            return new CustomShovelItem(
                    baseItem,
                    configuredTier,
                    properties
            );
        }

        if (base.contains("sword")) {
            return new CustomSwordItem(
                    baseItem,
                    configuredTier,
                    properties
            );
        }

        return new CustomGenericToolItem(
                baseItem,
                properties
        );
    }


    private static ItemAttributeModifiers createToolCombatAttributes(
            ProfessionToolConfig.ToolData toolData,
            String baseItemId
    ) {

        double damage =
                getModestToolAttackDamage(
                        toolData,
                        baseItemId
                );

        return ItemAttributeModifiers.builder()
                .add(
                        Attributes.ATTACK_DAMAGE,
                        new AttributeModifier(
                                ResourceLocation.fromNamespaceAndPath(
                                        "champutils",
                                        "profession_tool_attack_damage"
                                ),
                                damage,
                                AttributeModifier.Operation.ADD_VALUE
                        ),
                        EquipmentSlotGroup.MAINHAND
                )
                .add(
                        Attributes.ATTACK_SPEED,
                        new AttributeModifier(
                                ResourceLocation.fromNamespaceAndPath(
                                        "champutils",
                                        "profession_tool_attack_speed"
                                ),
                                -2.8D,
                                AttributeModifier.Operation.ADD_VALUE
                        ),
                        EquipmentSlotGroup.MAINHAND
                )
                .build();
    }

    private static double getModestToolAttackDamage(
            ProfessionToolConfig.ToolData toolData,
            String baseItemId
    ) {

        String base =
                baseItemId == null
                        ? ""
                        : baseItemId.toLowerCase();

        double damage;

        if (base.contains("axe")) {
            damage = 3.0D;
        } else if (base.contains("pickaxe")) {
            damage = 2.0D;
        } else if (base.contains("hoe")) {
            damage = 1.0D;
        } else if (base.contains("shovel")) {
            damage = 1.5D;
        } else if (base.contains("sword")) {
            damage = 3.0D;
        } else {
            damage = 1.0D;
        }

        String tier =
                getConfiguredTierName(
                        toolData
                );

        damage += switch (tier) {
            case "STONE" -> 0.25D;
            case "IRON" -> 0.5D;
            case "DIAMOND" -> 0.75D;
            case "NETHERITE" -> 1.0D;
            default -> 0.0D;
        };

        return damage;
    }

    public static Tier getConfiguredTier(
            ProfessionToolConfig.ToolData toolData
    ) {

        String tierName =
                getConfiguredTierName(
                        toolData
                );

        return switch (
                tierName
        ) {
            case "WOOD" -> Tiers.WOOD;
            case "STONE" -> Tiers.STONE;
            case "IRON" -> Tiers.IRON;
            case "NETHERITE" -> Tiers.NETHERITE;
            case "DIAMOND" -> Tiers.DIAMOND;
            default -> Tiers.WOOD;
        };
    }

    public static String getConfiguredTierName(
            ProfessionToolConfig.ToolData toolData
    ) {

        if (
                toolData != null &&
                        toolData.toolTier != null &&
                        !toolData.toolTier.isBlank()
        ) {
            return toolData.toolTier
                    .trim()
                    .toUpperCase();
        }

        String base =
                toolData == null || toolData.baseItem == null
                        ? ""
                        : toolData.baseItem.toLowerCase();

        if (base.contains("netherite")) {
            return "NETHERITE";
        }

        if (base.contains("diamond")) {
            return "DIAMOND";
        }

        if (base.contains("iron")) {
            return "IRON";
        }

        if (base.contains("stone")) {
            return "STONE";
        }

        if (base.contains("wooden") || base.contains("wood")) {
            return "WOOD";
        }

        return "WOOD";
    }

    public static int getConfiguredTierLevel(
            ProfessionToolConfig.ToolData toolData
    ) {

        return switch (
                getConfiguredTierName(
                        toolData
                )
        ) {
            case "STONE" -> 1;
            case "IRON" -> 2;
            case "DIAMOND", "NETHERITE" -> 3;
            default -> 0;
        };
    }

    public static int getRequiredTierLevel(
            BlockState state
    ) {

        if (state == null) {
            return 0;
        }

        if (state.is(BlockTags.NEEDS_DIAMOND_TOOL)) {
            return 3;
        }

        if (state.is(BlockTags.NEEDS_IRON_TOOL)) {
            return 2;
        }

        if (state.is(BlockTags.NEEDS_STONE_TOOL)) {
            return 1;
        }

        return 0;
    }

    public static boolean canHarvestWithConfiguredTier(
            ItemStack stack,
            BlockState state
    ) {

        String toolId =
                ProfessionToolUtil.getToolId(
                        stack
                );

        if (toolId == null) {
            return true;
        }

        ProfessionToolConfig.ToolData toolData =
                ProfessionToolConfig.TOOLS.get(
                        toolId
                );

        if (toolData == null) {
            return true;
        }

        if (
                "MINING".equalsIgnoreCase(
                        toolData.profession
                )
        ) {
            return true;
        }

        int toolTier =
                getConfiguredTierLevel(
                        toolData
                );

        int requiredTier =
                getRequiredTierLevel(
                        state
                );

        return toolTier >= requiredTier;
    }

    public static ItemStack createTool(
            String toolId
    ) {

        return createTool(
                toolId,
                false
        );
    }

    public static ItemStack createLootTool(
            String toolId,
            boolean ascended
    ) {

        ItemStack stack =
                createTool(
                        toolId,
                        ascended
                );

        if (
                !stack.isEmpty() &&
                        ascended
        ) {
            ProfessionToolMetadata.setDiscoveryAnnouncementEligible(
                    stack,
                    true
            );
        }

        return stack;
    }



    public static ItemStack createUnidentifiedPreviewStack(
            String toolId,
            String displayName
    ) {

        ProfessionToolConfig.ToolData toolData =
                ProfessionToolConfig.TOOLS.get(
                        toolId
                );

        if (toolData == null || toolData.baseItem == null || toolData.baseItem.isBlank()) {
            return ItemStack.EMPTY;
        }

        Item item;
        try {
            item = BuiltInRegistries.ITEM.get(
                    ResourceLocation.parse(
                            toolData.baseItem
                    )
            );
        } catch (Exception ignored) {
            return ItemStack.EMPTY;
        }

        if (item == null || item == Items.AIR) {
            return ItemStack.EMPTY;
        }

        ItemStack stack =
                new ItemStack(
                        item
                );

        applyUnidentifiedCustomModelData(
                stack,
                toolData
        );

        stack.remove(
                DataComponents.LORE
        );

        stack.remove(
                DataComponents.ENCHANTMENT_GLINT_OVERRIDE
        );

        stack.set(
                DataComponents.CUSTOM_NAME,
                Component.literal(
                        displayName == null || displayName.isBlank()
                                ? "Unidentified Tool"
                                : displayName
                ).withStyle(
                        ChatFormatting.LIGHT_PURPLE
                )
        );

        return stack;
    }

    private static boolean shouldRollAscendedUnidentified(
            ProfessionToolConfig.ToolData toolData
    ) {

        if (toolData == null) {
            return false;
        }

        double chancePercent =
                ProfessionToolConfig.ASCENDED_UNIDENTIFIED_CHANCE_PERCENT;

        if (chancePercent <= 0.0D) {
            return false;
        }

        if (chancePercent >= 100.0D) {
            return true;
        }

        return Math.random() * 100.0D < chancePercent;
    }

    private static boolean isLegendaryOrMythic(
            String rarity
    ) {

        if (rarity == null) {
            return false;
        }

        String normalized =
                rarity.trim().toUpperCase();

        return normalized.equals(
                "LEGENDARY"
        ) || normalized.equals(
                "MYTHIC"
        );
    }

    public static ItemStack createTool(
            String toolId,
            boolean ascended
    ) {

        ProfessionToolConfig.ToolData toolData =
                ProfessionToolConfig.TOOLS.get(
                        toolId
                );

        if (toolData == null) {
            System.out.println(
                    "[ChampUtils] Unknown tool id: " +
                            toolId
            );
            return ItemStack.EMPTY;
        }

        boolean finalAscended =
                ascended ||
                        shouldRollAscendedUnidentified(
                                toolData
                        );

        if (
                finalAscended &&
                        !toolData.hasAscendedVariant &&
                        !isLegendaryOrMythic(
                                toolData.rarity
                        )
        ) {
            System.out.println(
                    "[ChampUtils] Tool does not have an ascended variant enabled: " +
                            toolId
            );
            return ItemStack.EMPTY;
        }

        Item item =
                REGISTERED_TOOLS.get(
                        toolId
                );

        if (item == null) {

            try {

                item =
                        BuiltInRegistries.ITEM.get(
                                ResourceLocation.parse(
                                        toolData.baseItem
                                )
                        );

                if (
                        item == null ||
                                item == Items.AIR
                ) {
                    System.out.println(
                            "[ChampUtils] Failed fallback tool lookup: " +
                                    toolId
                    );
                    return ItemStack.EMPTY;
                }

                REGISTERED_TOOLS.put(
                        toolId,
                        item
                );

                System.out.println(
                        "[ChampUtils] Late-registered tool: " +
                                toolId
                );

            } catch (Exception e) {
                e.printStackTrace();
                return ItemStack.EMPTY;
            }
        }

        ItemStack stack =
                new ItemStack(
                        item
                );

        ProfessionToolMetadata.initializeUnidentifiedTool(
                stack,
                toolId,
                finalAscended
        );

        if (finalAscended) {
            ProfessionToolMetadata.setDiscoveryAnnouncementEligible(
                    stack,
                    true
            );
        }

        initializeDurabilityIfNeeded(
                stack,
                toolData,
                true
        );

        applyDurabilityComponents(
                stack,
                toolData
        );

        /*
         Keep legacy key for your older helper/listener code until we migrate
         ProfessionToolUtil fully to ProfessionToolMetadata.
         */
        setLegacyToolId(
                stack,
                toolId
        );

        refreshToolStack(
                stack
        );

        return stack;
    }

    public static void refreshToolStack(
            ItemStack stack
    ) {

        if (
                stack == null ||
                        stack.isEmpty()
        ) {
            return;
        }

        if (!ProfessionToolMetadata.isProfessionTool(stack)) {
            return;
        }

        String toolId =
                ProfessionToolMetadata.getToolId(
                        stack
                );

        if (
                toolId == null ||
                        toolId.isBlank()
        ) {
            return;
        }

        ProfessionToolConfig.ToolData toolData =
                ProfessionToolConfig.TOOLS.get(
                        toolId
                );

        if (toolData == null) {
            return;
        }

        initializeDurabilityIfNeeded(
                stack,
                toolData,
                false
        );

        applyDurabilityComponents(
                stack,
                toolData
        );

        applyAscendedGlint(
                stack
        );

        boolean identified =
                ProfessionToolMetadata.isIdentified(
                        stack
                );

        if (identified) {
            applyIdentifiedDisplay(
                    stack,
                    toolId,
                    toolData
            );
        } else {
            applyUnidentifiedDisplay(
                    stack,
                    toolId,
                    toolData
            );
        }
    }

    private static void applyUnidentifiedDisplay(
            ItemStack stack,
            String toolId,
            ProfessionToolConfig.ToolData toolData
    ) {

        applyUnidentifiedCustomModelData(
                stack,
                toolData
        );

        String toolType =
                getMysteryToolTypeName(
                        toolData
                );

        boolean ascended =
                ProfessionToolMetadata.isAscended(
                        stack
                );

        stack.set(
                DataComponents.CUSTOM_NAME,
                Component.literal(
                        (ascended ? "Ascended Unidentified " : "Unidentified ") +
                                toolType
                ).withStyle(
                        ChatFormatting.DARK_GRAY
                )
        );

        List<Component> lore =
                new ArrayList<>();

        lore.add(
                Component.literal(
                        "Mystery " + toolType
                ).withStyle(
                        ChatFormatting.GRAY
                )
        );

        addItemLockLore(
                lore,
                stack
        );

        lore.add(
                Component.literal(" ")
        );

        lore.add(
                Component.literal(
                        "Unidentified"
                ).withStyle(
                        ChatFormatting.GOLD
                )
        );

        lore.add(
                Component.literal(
                        "Identify this item to reveal its name, rarity, stats, level requirement, and abilities."
                ).withStyle(
                        ChatFormatting.DARK_GRAY
                )
        );

        lore.add(
                Component.literal(
                        "Cannot be used until identified."
                ).withStyle(
                        ChatFormatting.RED
                )
        );

        stack.set(
                DataComponents.LORE,
                new ItemLore(
                        lore
                )
        );
    }


    private static String getMysteryToolTypeName(
            ProfessionToolConfig.ToolData toolData
    ) {
        if (toolData == null || toolData.baseItem == null) {
            return "Tool";
        }

        String baseItem =
                toolData.baseItem.toLowerCase();

        if (baseItem.contains("pickaxe")) {
            return "Pickaxe";
        }

        if (baseItem.contains("axe")) {
            return "Axe";
        }

        if (baseItem.contains("hoe")) {
            return "Hoe";
        }

        if (baseItem.contains("sword")) {
            return "Sword";
        }

        if (baseItem.contains("shovel")) {
            return "Shovel";
        }

        return "Tool";
    }

    private static void applyIdentifiedDisplay(
            ItemStack stack,
            String toolId,
            ProfessionToolConfig.ToolData toolData
    ) {

        applyCustomModelData(
                stack,
                toolData.customModelData
        );

        String displayName =
                ProfessionToolConfig.getDisplayName(
                        toolId,
                        toolData
                );

        double quality =
                ProfessionToolMetadata.getQuality(
                        stack
                );

        boolean ascended =
                ProfessionToolMetadata.isAscended(
                        stack
                );

        stack.set(
                DataComponents.CUSTOM_NAME,
                Component.literal(
                        (ascended ? "Ascended " : "") +
                                displayName +
                                " "
                ).withStyle(
                        getRarityColor(
                                toolData.rarity
                        )
                ).append(
                        buildPercentComponent(
                                quality
                        )
                )
        );

        List<Component> lore =
                new ArrayList<>();

        addHeaderLore(
                lore,
                toolData
        );

        addDurabilityLore(
                lore,
                stack
        );

        addItemLockLore(
                lore,
                stack
        );

        if (ascended) {
            lore.add(
                    Component.literal(
                            "Ascended Tracker Variant"
                    ).withStyle(
                            ChatFormatting.GRAY
                    )
            );
        }

        lore.add(
                Component.literal(
                        "Quality: "
                ).withStyle(
                        ChatFormatting.WHITE
                ).append(
                        buildPercentComponent(
                                quality
                        )
                )
        );

        lore.add(
                Component.literal(
                        "Rerolls: " +
                                ProfessionToolMetadata.getRerolls(
                                        stack
                                )
                ).withStyle(
                        ChatFormatting.GRAY
                )
        );

        addRolledStatsLore(
                lore,
                stack,
                toolData
        );


        addTrackerLore(
                lore,
                stack
        );

        // Tool passives are intentionally not shown as separate bonuses.
        // Player-facing power should come from rolled stats only.

        addActiveAbilityLore(
                lore,
                toolData
        );

        stack.set(
                DataComponents.LORE,
                new ItemLore(
                        lore
                )
        );
    }

    private static void addHeaderLore(
            List<Component> lore,
            ProfessionToolConfig.ToolData toolData
    ) {

        lore.add(
                Component.literal(
                        formatRarity(
                                toolData.rarity
                        ) +
                                " " +
                                formatWords(
                                        toolData.profession
                                ) +
                                " Tool"
                ).withStyle(
                        getRarityColor(
                                toolData.rarity
                        )
                )
        );

    }


    private static void addItemLockLore(
            List<Component> lore,
            ItemStack stack
    ) {

        if (!ProfessionToolMetadata.isLocked(stack)) {
            return;
        }

        lore.add(
                Component.literal(
                        "🔒 Locked - protected from reroll/salvage"
                ).withStyle(
                        ChatFormatting.GOLD,
                        ChatFormatting.BOLD
                )
        );
    }

    private static void addDurabilityLore(
            List<Component> lore,
            ItemStack stack
    ) {

        int max =
                ProfessionToolMetadata.getMaxDurability(
                        stack
                );

        if (max <= 0) {
            return;
        }

        int current =
                Math.max(
                        0,
                        Math.min(
                                max,
                                ProfessionToolMetadata.getCurrentDurability(
                                        stack
                                )
                        )
                );

        ChatFormatting color =
                current <= 0
                        ? ChatFormatting.RED
                        : ChatFormatting.GRAY;

        lore.add(
                Component.literal(
                        "Durability: " +
                                current +
                                "/" +
                                max
                ).withStyle(
                        color
                )
        );

        if (current <= 0) {
            lore.add(
                    Component.literal(
                            "Broken - repair before use."
                    ).withStyle(
                            ChatFormatting.RED
                    )
            );
        }
    }

    private static void addRolledStatsLore(
            List<Component> lore,
            ItemStack stack,
            ProfessionToolConfig.ToolData toolData
    ) {

        Map<String, Double> rolledStats =
                ProfessionToolMetadata.getRolledStats(
                        stack
                );

        if (
                rolledStats == null ||
                        rolledStats.isEmpty()
        ) {
            return;
        }

        lore.add(
                Component.literal(" ")
        );

        lore.add(
                Component.literal(
                        "Rolled Stats"
                ).withStyle(
                        ChatFormatting.GOLD
                )
        );

        for (
                Map.Entry<String, Double> stat :
                rolledStats.entrySet()
        ) {

            double statQuality =
                    getStatQualityPercent(
                            toolData,
                            stat.getKey(),
                            stat.getValue()
                    );

            Component line;

            if (statQuality >= 100.0D) {
                line =
                        Component.literal(
                                " +" +
                                        formatStatValue(
                                                stat.getKey(),
                                                stat.getValue()
                                        ) +
                                        " " +
                                        formatStatName(
                                                stat.getKey()
                                        ) +
                                        " [100%]"
                        ).withStyle(
                                ChatFormatting.GOLD,
                                ChatFormatting.BOLD
                        );
            } else {
                line =
                        Component.literal(
                                " +"
                        ).withStyle(
                                ChatFormatting.WHITE
                        ).append(
                                buildStatValueComponent(
                                        stat.getKey(),
                                        stat.getValue(),
                                        statQuality
                                )
                        ).append(
                                Component.literal(
                                        " " +
                                                formatStatName(
                                                        stat.getKey()
                                                ) +
                                                " "
                                ).withStyle(
                                        ChatFormatting.WHITE
                                )
                        ).append(
                                buildPercentComponent(
                                        statQuality
                                )
                        );
            }

            lore.add(
                    line
            );
        }
    }



    private static void addTrackerLore(
            List<Component> lore,
            ItemStack stack
    ) {

        if (
                !ProfessionToolMetadata.isAscended(
                        stack
                )
        ) {
            return;
        }

        lore.add(
                Component.literal(" ")
        );

        lore.add(
                Component.literal(
                        "Ascended Tracker"
                ).withStyle(
                        ChatFormatting.GRAY
                )
        );

        String selectedTracker =
                ProfessionToolMetadata.getSelectedTracker(
                        stack
                );

        if (
                selectedTracker == null ||
                        selectedTracker.isBlank()
        ) {
            lore.add(
                    Component.literal(
                            " No tracker selected yet."
                    ).withStyle(
                            ChatFormatting.DARK_GRAY
                    )
            );
            return;
        }

        long value =
                ProfessionToolMetadata.getTracker(
                        stack,
                        selectedTracker
                );

        lore.add(
                Component.literal(
                        " " +
                                formatTrackerName(
                                        selectedTracker
                                ) +
                                ": " +
                                value
                ).withStyle(
                        ChatFormatting.WHITE
                )
        );
    }


    private static void addPassivesLore(
            List<Component> lore,
            ProfessionToolConfig.ToolData toolData
    ) {

        if (
                toolData.passives == null ||
                        toolData.passives.isEmpty()
        ) {
            return;
        }

        lore.add(
                Component.literal(" ")
        );

        lore.add(
                Component.literal(
                        "Passives"
                ).withStyle(
                        ChatFormatting.GOLD
                )
        );

        for (
                String passive :
                toolData.passives
        ) {

            lore.add(
                    Component.literal(
                            " " +
                                    formatWords(
                                            passive
                                    )
                    ).withStyle(
                            ChatFormatting.GRAY
                    )
            );
        }
    }

    private static void addActiveAbilityLore(
            List<Component> lore,
            ProfessionToolConfig.ToolData toolData
    ) {

        if (
                toolData.activeAbility == null ||
                        toolData.activeAbility.isBlank()
        ) {
            return;
        }

        lore.add(
                Component.literal(" ")
        );

        lore.add(
                Component.literal(
                        "Active Ability"
                ).withStyle(
                        ChatFormatting.AQUA
                )
        );

        lore.add(
                Component.literal(
                        " " +
                                formatWords(
                                        toolData.activeAbility
                                )
                ).withStyle(
                        ChatFormatting.GRAY
                )
        );

        lore.add(
                Component.literal(
                        " Cooldown: " +
                                toolData.activeCooldownSeconds +
                                "s"
                ).withStyle(
                        ChatFormatting.DARK_GRAY
                )
        );

        if (toolData.activeDurationSeconds > 0) {
            lore.add(
                    Component.literal(
                            " Duration: " +
                                    toolData.activeDurationSeconds +
                                    "s"
                    ).withStyle(
                            ChatFormatting.DARK_GRAY
                    )
            );
        }
    }

    private static double getStatQualityPercent(
            ProfessionToolConfig.ToolData toolData,
            String statId,
            double rolledValue
    ) {

        if (
                toolData == null ||
                        toolData.statRanges == null ||
                        statId == null
        ) {
            return 0.0D;
        }

        ProfessionToolConfig.StatRange range =
                toolData.statRanges.get(
                        statId
                );

        if (range == null) {
            return 0.0D;
        }

        double min =
                Math.min(
                        range.min,
                        range.max
                );

        double max =
                Math.max(
                        range.min,
                        range.max
                );

        /*
         * Lore displays stat values as whole percentages.
         * Quality should therefore be based on the displayed value, not the
         * hidden decimal.
         *
         * Example: range 0.0 -> 1.0
         *   rolled 0.9 displays as +0%, so quality should show [0%]
         *   rolled 1.0 displays as +1%, so quality should show [100%]
         */
        double displayedMin =
                Math.floor(
                        min
                );

        double displayedMax =
                Math.floor(
                        max
                );

        double displayedValue =
                Math.floor(
                        rolledValue
                );

        // Quality must match what the player actually sees in lore.
        min = displayedMin;
        max = displayedMax;
        rolledValue = displayedValue;

        if (max <= min) {
            if (max <= 0.0D) {
                return 0.0D;
            }

            return 100.0D;
        }

        double percent =
                ((rolledValue - min) /
                        (max - min)) *
                        100.0D;

        percent =
                Math.max(
                        0.0D,
                        Math.min(
                                100.0D,
                                percent
                        )
                );

        return Math.floor(
                percent
        );
    }

    private static Component buildPercentComponent(
            double quality
    ) {

        int rounded =
                (int) Math.floor(
                        quality
                );

        if (rounded >= 100) {
            return buildRainbowText(
                    "[100%]"
            );
        }

        ChatFormatting color =
                getStatQualityColor(
                        rounded
                );

        return Component.literal(
                "[" +
                        rounded +
                        "%]"
        ).withStyle(
                color
        );
    }

    private static Component buildStatValueComponent(
            String statId,
            double value,
            double quality
    ) {

        int rounded =
                (int) Math.floor(
                        quality
                );

        String text =
                formatStatValue(
                        statId,
                        value
                );

        if (rounded >= 100) {
            return buildRainbowText(
                    text
            );
        }

        return Component.literal(
                text
        ).withStyle(
                getStatQualityColor(
                        rounded
                )
        );
    }

    private static ChatFormatting getStatQualityColor(
            int quality
    ) {

        if (quality <= 25) {
            return ChatFormatting.RED;
        }

        if (quality <= 50) {
            return ChatFormatting.YELLOW;
        }

        if (quality <= 75) {
            return ChatFormatting.GREEN;
        }

        return ChatFormatting.BLUE;
    }

    private static Component buildRainbowText(
            String text
    ) {

        ChatFormatting[] colors =
                new ChatFormatting[]{
                        ChatFormatting.RED,
                        ChatFormatting.GOLD,
                        ChatFormatting.YELLOW,
                        ChatFormatting.GREEN,
                        ChatFormatting.AQUA,
                        ChatFormatting.BLUE,
                        ChatFormatting.LIGHT_PURPLE
                };

        Component result =
                Component.empty();

        for (int i = 0; i < text.length(); i++) {
            result =
                    result.copy()
                            .append(
                                    Component.literal(
                                            String.valueOf(
                                                    text.charAt(i)
                                            )
                                    ).withStyle(
                                            colors[i % colors.length]
                                    )
                            );
        }

        return result;
    }

    private static void setLegacyToolId(
            ItemStack stack,
            String toolId
    ) {

        CustomData customData =
                stack.getOrDefault(
                        DataComponents.CUSTOM_DATA,
                        CustomData.EMPTY
                );

        CompoundTag tag =
                customData.copyTag();

        tag.putString(
                "ChampUtilsToolId",
                toolId
        );

        stack.set(
                DataComponents.CUSTOM_DATA,
                CustomData.of(
                        tag
                )
        );
    }


    public static boolean damageTool(
            ItemStack stack,
            int amount
    ) {

        if (
                stack == null ||
                        stack.isEmpty() ||
                        amount <= 0 ||
                        !ProfessionToolMetadata.isProfessionTool(stack)
        ) {
            return false;
        }

        String toolId =
                ProfessionToolMetadata.getToolId(
                        stack
                );

        ProfessionToolConfig.ToolData toolData =
                ProfessionToolConfig.TOOLS.get(
                        toolId
                );

        if (toolData == null) {
            return false;
        }

        initializeDurabilityIfNeeded(
                stack,
                toolData,
                false
        );

        int max =
                ProfessionToolMetadata.getMaxDurability(
                        stack
                );

        if (max <= 0) {
            return false;
        }

        int current =
                ProfessionToolMetadata.getCurrentDurability(
                        stack
                );

        if (current <= 0) {
            applyDurabilityComponents(
                    stack,
                    toolData
            );
            return true;
        }


        ProfessionToolMetadata.setCurrentDurability(
                stack,
                Math.max(
                        0,
                        current - amount
                )
        );

        refreshToolStack(
                stack
        );

        return true;
    }

    public static boolean repairTool(
            ItemStack stack
    ) {

        if (
                stack == null ||
                        stack.isEmpty() ||
                        !ProfessionToolMetadata.isProfessionTool(stack)
        ) {
            return false;
        }

        String toolId =
                ProfessionToolMetadata.getToolId(
                        stack
                );

        ProfessionToolConfig.ToolData toolData =
                ProfessionToolConfig.TOOLS.get(
                        toolId
                );

        if (toolData == null) {
            return false;
        }

        initializeDurabilityIfNeeded(
                stack,
                toolData,
                false
        );

        int max =
                ProfessionToolMetadata.getMaxDurability(
                        stack
                );

        if (max <= 0) {
            return false;
        }

        int current =
                ProfessionToolMetadata.getCurrentDurability(
                        stack
                );

        double percent =
                toolData.repairDurabilityPercent <= 0.0D
                        ? 100.0D
                        : toolData.repairDurabilityPercent;

        int restore =
                Math.max(
                        1,
                        (int) Math.ceil(
                                max * (percent / 100.0D)
                        )
                );

        ProfessionToolMetadata.setCurrentDurability(
                stack,
                Math.min(
                        max,
                        current + restore
                )
        );

        refreshToolStack(
                stack
        );

        return true;
    }

    public static void initializeDurabilityIfNeeded(
            ItemStack stack,
            ProfessionToolConfig.ToolData toolData,
            boolean forceFull
    ) {

        if (
                stack == null ||
                        stack.isEmpty() ||
                        toolData == null
        ) {
            return;
        }

        int max =
                calculateMaxDurability(
                        stack,
                        toolData
                );

        if (max <= 0) {
            return;
        }

        int oldMax =
                ProfessionToolMetadata.getMaxDurability(
                        stack
                );

        int oldCurrent =
                ProfessionToolMetadata.getCurrentDurability(
                        stack
                );

        if (forceFull || oldMax <= 0) {
            ProfessionToolMetadata.setMaxDurability(
                    stack,
                    max
            );

            ProfessionToolMetadata.setCurrentDurability(
                    stack,
                    max
            );
            return;
        }

        if (oldMax != max) {
            double ratio =
                    oldMax <= 0
                            ? 1.0D
                            : Math.max(
                                    0.0D,
                                    Math.min(
                                            1.0D,
                                            oldCurrent / (double) oldMax
                                    )
                            );

            ProfessionToolMetadata.setMaxDurability(
                    stack,
                    max
            );

            ProfessionToolMetadata.setCurrentDurability(
                    stack,
                    Math.max(
                            0,
                            Math.min(
                                    max,
                                    (int) Math.round(
                                            max * ratio
                                    )
                            )
                    )
            );
        }
    }

    private static int calculateMaxDurability(
            ItemStack stack,
            ProfessionToolConfig.ToolData toolData
    ) {

        int base =
                getBaseMaxDurability(
                        toolData,
                        null
                );

        double durabilityBonus =
                ProfessionToolMetadata.isIdentified(
                        stack
                )
                        ? ProfessionToolUtil.getStat(
                                stack,
                                "durabilityBonus"
                        )
                        : 0.0D;

        return Math.max(
                1,
                (int) Math.round(
                        base * (1.0D + Math.max(0.0D, durabilityBonus) / 100.0D)
                )
        );
    }

    private static int getBaseMaxDurability(
            ProfessionToolConfig.ToolData toolData,
            Item fallbackBaseItem
    ) {

        if (
                toolData != null &&
                        toolData.baseDurability > 0
        ) {
            return toolData.baseDurability;
        }

        Item baseItem =
                fallbackBaseItem;

        if (
                baseItem == null &&
                        toolData != null &&
                        toolData.baseItem != null &&
                        !toolData.baseItem.isBlank()
        ) {
            try {
                baseItem =
                        BuiltInRegistries.ITEM.get(
                                ResourceLocation.parse(
                                        toolData.baseItem
                                )
                        );
            } catch (Exception ignored) {
            }
        }

        if (
                baseItem != null &&
                        baseItem != Items.AIR
        ) {
            ItemStack baseStack =
                    new ItemStack(
                            baseItem
                    );

            if (baseStack.isDamageableItem()) {
                return Math.max(
                        1,
                        baseStack.getMaxDamage()
                );
            }
        }

        return 250;
    }

    private static void applyDurabilityComponents(
            ItemStack stack,
            ProfessionToolConfig.ToolData toolData
    ) {

        if (
                stack == null ||
                        stack.isEmpty()
        ) {
            return;
        }

        initializeDurabilityIfNeeded(
                stack,
                toolData,
                false
        );

        int max =
                ProfessionToolMetadata.getMaxDurability(
                        stack
                );

        if (max <= 0) {
            return;
        }

        int current =
                Math.max(
                        0,
                        Math.min(
                                max,
                                ProfessionToolMetadata.getCurrentDurability(
                                        stack
                                )
                        )
                );

        stack.remove(
                DataComponents.UNBREAKABLE
        );

        stack.set(
                DataComponents.MAX_DAMAGE,
                max
        );

        stack.set(
                DataComponents.DAMAGE,
                Math.max(
                        0,
                        Math.min(
                                max - 1,
                                max - current
                        )
                )
        );
    }

    private static void applyUnidentifiedCustomModelData(
            ItemStack stack,
            ProfessionToolConfig.ToolData toolData
    ) {

        if (
                stack == null ||
                        stack.isEmpty() ||
                        toolData == null ||
                        toolData.baseItem == null
        ) {
            return;
        }

        String baseItem =
                toolData.baseItem.toLowerCase();

        String rarity =
                normalizeRarityName(
                        toolData.rarity
                );

        if (baseItem.contains("pickaxe")) {
            applyCustomModelData(
                    stack,
                    getUnidentifiedPickaxeModelData(
                            rarity
                    )
            );
            return;
        }

        if (baseItem.contains("axe")) {
            applyCustomModelData(
                    stack,
                    getUnidentifiedAxeModelData(
                            rarity
                    )
            );
            return;
        }

        if (baseItem.contains("hoe")) {
            applyCustomModelData(
                    stack,
                    getUnidentifiedHoeModelData(
                            rarity
                    )
            );
            return;
        }

        if (baseItem.contains("sword")) {
            applyCustomModelData(
                    stack,
                    getUnidentifiedSwordModelData(
                            rarity
                    )
            );
            return;
        }

        if (baseItem.contains("shovel")) {
            applyCustomModelData(
                    stack,
                    getUnidentifiedShovelModelData(
                            rarity
                    )
            );
        }
    }

    private static String normalizeRarityName(
            String rarity
    ) {

        if (
                rarity == null ||
                        rarity.isBlank()
        ) {
            return "COMMON";
        }

        return rarity
                .trim()
                .toUpperCase();
    }

    private static int getUnidentifiedPickaxeModelData(
            String rarity
    ) {

        return switch (rarity) {
            case "UNCOMMON" -> UNIDENTIFIED_PICKAXE_UNCOMMON_MODEL_DATA;
            case "RARE" -> UNIDENTIFIED_PICKAXE_RARE_MODEL_DATA;
            case "EPIC" -> UNIDENTIFIED_PICKAXE_EPIC_MODEL_DATA;
            case "LEGENDARY" -> UNIDENTIFIED_PICKAXE_LEGENDARY_MODEL_DATA;
            case "MYTHIC" -> UNIDENTIFIED_PICKAXE_MYTHIC_MODEL_DATA;
            case "COMMON" -> UNIDENTIFIED_PICKAXE_COMMON_MODEL_DATA;
            default -> UNIDENTIFIED_PICKAXE_MODEL_DATA;
        };
    }

    private static int getUnidentifiedAxeModelData(
            String rarity
    ) {

        return switch (rarity) {
            case "UNCOMMON" -> UNIDENTIFIED_AXE_UNCOMMON_MODEL_DATA;
            case "RARE" -> UNIDENTIFIED_AXE_RARE_MODEL_DATA;
            case "EPIC" -> UNIDENTIFIED_AXE_EPIC_MODEL_DATA;
            case "LEGENDARY" -> UNIDENTIFIED_AXE_LEGENDARY_MODEL_DATA;
            case "MYTHIC" -> UNIDENTIFIED_AXE_MYTHIC_MODEL_DATA;
            case "COMMON" -> UNIDENTIFIED_AXE_COMMON_MODEL_DATA;
            default -> UNIDENTIFIED_AXE_MODEL_DATA;
        };
    }

    private static int getUnidentifiedHoeModelData(
            String rarity
    ) {

        return switch (rarity) {
            case "UNCOMMON" -> UNIDENTIFIED_HOE_UNCOMMON_MODEL_DATA;
            case "RARE" -> UNIDENTIFIED_HOE_RARE_MODEL_DATA;
            case "EPIC" -> UNIDENTIFIED_HOE_EPIC_MODEL_DATA;
            case "LEGENDARY" -> UNIDENTIFIED_HOE_LEGENDARY_MODEL_DATA;
            case "MYTHIC" -> UNIDENTIFIED_HOE_MYTHIC_MODEL_DATA;
            case "COMMON" -> UNIDENTIFIED_HOE_COMMON_MODEL_DATA;
            default -> UNIDENTIFIED_HOE_MODEL_DATA;
        };
    }

    private static int getUnidentifiedSwordModelData(
            String rarity
    ) {

        return switch (rarity) {
            case "UNCOMMON" -> UNIDENTIFIED_SWORD_UNCOMMON_MODEL_DATA;
            case "RARE" -> UNIDENTIFIED_SWORD_RARE_MODEL_DATA;
            case "EPIC" -> UNIDENTIFIED_SWORD_EPIC_MODEL_DATA;
            case "LEGENDARY" -> UNIDENTIFIED_SWORD_LEGENDARY_MODEL_DATA;
            case "MYTHIC" -> UNIDENTIFIED_SWORD_MYTHIC_MODEL_DATA;
            case "COMMON" -> UNIDENTIFIED_SWORD_COMMON_MODEL_DATA;
            default -> UNIDENTIFIED_SWORD_MODEL_DATA;
        };
    }

    private static int getUnidentifiedShovelModelData(
            String rarity
    ) {

        return switch (rarity) {
            case "UNCOMMON" -> UNIDENTIFIED_SHOVEL_UNCOMMON_MODEL_DATA;
            case "RARE" -> UNIDENTIFIED_SHOVEL_RARE_MODEL_DATA;
            case "EPIC" -> UNIDENTIFIED_SHOVEL_EPIC_MODEL_DATA;
            case "LEGENDARY" -> UNIDENTIFIED_SHOVEL_LEGENDARY_MODEL_DATA;
            case "MYTHIC" -> UNIDENTIFIED_SHOVEL_MYTHIC_MODEL_DATA;
            case "COMMON" -> UNIDENTIFIED_SHOVEL_COMMON_MODEL_DATA;
            default -> UNIDENTIFIED_SHOVEL_MODEL_DATA;
        };
    }

    private static void applyCustomModelData(
            ItemStack stack,
            int customModelData
    ) {

        if (
                stack == null ||
                        stack.isEmpty()
        ) {
            return;
        }

        if (customModelData <= 0) {
            stack.remove(
                    DataComponents.CUSTOM_MODEL_DATA
            );
            return;
        }

        stack.set(
                DataComponents.CUSTOM_MODEL_DATA,
                new CustomModelData(
                        customModelData
                )
        );
    }

    private static void applyAscendedGlint(
            ItemStack stack
    ) {

        if (
                stack == null ||
                        stack.isEmpty()
        ) {
            return;
        }

        stack.set(
                DataComponents.ENCHANTMENT_GLINT_OVERRIDE,
                ProfessionToolMetadata.isAscended(
                        stack
                )
        );
    }



    private static String formatTrackerName(
            String trackerId
    ) {

        if (
                trackerId == null ||
                        trackerId.isBlank()
        ) {
            return "Unknown";
        }

        return formatWords(
                trackerId
        );
    }

    private static String formatRarity(
            String rarity
    ) {

        if (
                rarity == null ||
                        rarity.isBlank()
        ) {
            return "COMMON";
        }

        return rarity
                .replace("_", " ")
                .toUpperCase();
    }

    private static String formatWords(
            String value
    ) {

        if (
                value == null ||
                        value.isBlank()
        ) {
            return "";
        }

        String[] parts =
                value.replace("_", " ")
                        .replace("-", " ")
                        .trim()
                        .split("\\s+");

        StringBuilder builder =
                new StringBuilder();

        for (String part : parts) {

            if (part.isBlank()) {
                continue;
            }

            builder.append(
                    Character.toUpperCase(
                            part.charAt(0)
                    )
            );

            if (part.length() > 1) {
                builder.append(
                        part.substring(1)
                                .toLowerCase()
                );
            }

            builder.append(" ");
        }

        return builder
                .toString()
                .trim()
                .replaceAll("\\bXp\\b", "XP");
    }

    private static String formatStatName(
            String stat
    ) {

        if (
                stat == null ||
                        stat.isBlank()
        ) {
            return "";
        }

        return switch (stat) {
            case "damage", "slayingDamage", "damageBonus" -> "Damage";
            case "critChance" -> "Crit Chance";
            case "lifestealChance" -> "Lifesteal Chance";
            default -> formatWords(
                    stat.replaceAll(
                            "([a-z])([A-Z])",
                            "$1 $2"
                    )
            );
        };
    }

    private static String formatStatValue(
            String statId,
            double value
    ) {

        return formatDecimal(
                value
        ) + "%";
    }

    private static String formatDecimal(
            double value
    ) {

        return String.valueOf(
                (int) Math.floor(
                        value
                )
        );
    }

    private static ChatFormatting getQualityColor(
            double quality
    ) {

        if (quality >= 90.0D) {
            return ChatFormatting.LIGHT_PURPLE;
        }

        if (quality >= 75.0D) {
            return ChatFormatting.GOLD;
        }

        return ChatFormatting.WHITE;
    }

    public static Item getTool(
            String toolId
    ) {

        return REGISTERED_TOOLS.get(
                toolId
        );
    }

    public static Map<String, Item> getRegisteredTools() {

        return REGISTERED_TOOLS;
    }

    private static Rarity getRarity(
            String rarity
    ) {

        if (rarity == null) {
            return Rarity.COMMON;
        }

        return switch (
                rarity.toUpperCase()
                ) {
            case "UNCOMMON" -> Rarity.UNCOMMON;
            case "RARE" -> Rarity.RARE;
            case "EPIC", "LEGENDARY", "MYTHIC" -> Rarity.EPIC;
            default -> Rarity.COMMON;
        };
    }


    private static String toRoman(
            int value
    ) {

        if (value <= 0) {
            return "0";
        }

        String[] romans =
                new String[]{
                        "",
                        "I",
                        "II",
                        "III",
                        "IV",
                        "V",
                        "VI",
                        "VII",
                        "VIII",
                        "IX",
                        "X"
                };

        if (value < romans.length) {
            return romans[value];
        }

        return String.valueOf(
                value
        );
    }

    private static ChatFormatting getRarityColor(
            String rarity
    ) {

        if (rarity == null) {
            return ChatFormatting.WHITE;
        }

        return switch (
                rarity.toUpperCase()
                ) {
            case "UNCOMMON" -> ChatFormatting.DARK_GREEN;
            case "RARE" -> ChatFormatting.AQUA;
            case "EPIC" -> ChatFormatting.DARK_PURPLE;
            case "LEGENDARY" -> ChatFormatting.GOLD;
            case "MYTHIC" -> ChatFormatting.LIGHT_PURPLE;
            default -> ChatFormatting.WHITE;
        };
    }

    public static float applyMiningSpeedStat(
            ItemStack stack,
            float baseSpeed
    ) {

        if (
                stack == null ||
                        stack.isEmpty() ||
                        baseSpeed <= 1.0F ||
                        !ProfessionToolMetadata.isProfessionTool(stack) ||
                        !ProfessionToolMetadata.isIdentified(stack) ||
                        ProfessionToolMetadata.isBroken(stack)
        ) {
            return baseSpeed;
        }

        double miningSpeed =
                ProfessionToolUtil.getStat(
                        stack,
                        "miningSpeed"
                );

        if (miningSpeed <= 0.0D) {
            return baseSpeed;
        }

        return (float) (
                baseSpeed +
                        getEfficiencyStyleMiningSpeedBonus(
                                miningSpeed
                        )
        );
    }

    public static double getMiningSpeedMultiplier(
            double miningSpeedPercent
    ) {

        if (miningSpeedPercent <= 0.0D) {
            return 1.0D;
        }

        return 1.0D +
                (miningSpeedPercent / 100.0D);
    }

    public static double getEfficiencyStyleMiningSpeedBonus(
            double miningSpeedPercent
    ) {

        if (miningSpeedPercent <= 0.0D) {
            return 0.0D;
        }

        /*
         * Vanilla Efficiency does not multiply speed by a flat percent.
         * It adds an efficiency bonus to the tool's destroy speed:
         *
         *   level 1 -> +2
         *   level 2 -> +5
         *   level 3 -> +10
         *   level 4 -> +17
         *   level 5 -> +26
         *
         * ChampUtils keeps the config/display as percentages, then converts
         * every 50% miningSpeed into one virtual Efficiency level. Fractional
         * values are allowed so 23% and 230% are no longer in the same
         * barely-noticeable vanilla multiplier bucket.
         */
        double virtualEfficiencyLevel =
                miningSpeedPercent / 50.0D;

        return (virtualEfficiencyLevel * virtualEfficiencyLevel) + 1.0D;
    }

    public static class CustomPickaxeItem extends PickaxeItem implements PolymerItem {

        private final Item baseItem;

        public CustomPickaxeItem(
                Item baseItem,
                Tier tier,
                Properties properties
        ) {

            super(
                    tier,
                    properties
            );

            this.baseItem =
                    baseItem;
        }

        @Override
        public float getDestroySpeed(
                ItemStack stack,
                BlockState state
        ) {

            return ProfessionToolManager.applyMiningSpeedStat(
                    stack,
                    super.getDestroySpeed(
                            stack,
                            state
                    )
            );
        }

        @Override
        public boolean isCorrectToolForDrops(
                ItemStack stack,
                BlockState state
        ) {

            return ProfessionToolManager.canHarvestWithConfiguredTier(
                    stack,
                    state
            );
        }

        @Override
        public boolean mineBlock(
                ItemStack stack,
                Level level,
                BlockState state,
                BlockPos pos,
                LivingEntity miningEntity
        ) {

            if (!level.isClientSide && state.getDestroySpeed(level, pos) != 0.0F) {
                if (
                        miningEntity instanceof ServerPlayer serverPlayer &&
                                DurabilitySavePassive.shouldPreserveDurability(
                                        serverPlayer,
                                        stack,
                                        serverPlayer.serverLevel(),
                                        pos,
                                        state
                                )
                ) {
                    return true;
                }

                ProfessionToolManager.damageTool(
                        stack,
                        1
                );
            }

            return true;
        }

        @Override
        public boolean hurtEnemy(
                ItemStack stack,
                LivingEntity target,
                LivingEntity attacker
        ) {

            if (!attacker.level().isClientSide) {
                ProfessionToolManager.damageTool(
                        stack,
                        1
                );
            }

            // Custom profession durability is handled above. Returning false prevents
            // vanilla combat durability from pushing the stack past max damage and
            // deleting it instead of leaving it broken-but-repairable.
            return false;
        }

        @Override
        public boolean isEnchantable(
                ItemStack stack
        ) {

            return false;
        }

        @Override
        public Item getPolymerItem(
                ItemStack stack,
                ServerPlayer player
        ) {

            return baseItem;
        }
    }

    public static class CustomAxeItem extends AxeItem implements PolymerItem {

        private final Item baseItem;

        public CustomAxeItem(
                Item baseItem,
                Tier tier,
                Properties properties
        ) {

            super(
                    tier,
                    properties
            );

            this.baseItem =
                    baseItem;
        }

        @Override
        public float getDestroySpeed(
                ItemStack stack,
                BlockState state
        ) {

            return ProfessionToolManager.applyMiningSpeedStat(
                    stack,
                    super.getDestroySpeed(
                            stack,
                            state
                    )
            );
        }

        @Override
        public boolean mineBlock(
                ItemStack stack,
                Level level,
                BlockState state,
                BlockPos pos,
                LivingEntity miningEntity
        ) {

            if (!level.isClientSide && state.getDestroySpeed(level, pos) != 0.0F) {
                if (
                        miningEntity instanceof ServerPlayer serverPlayer &&
                                DurabilitySavePassive.shouldPreserveDurability(
                                        serverPlayer,
                                        stack,
                                        serverPlayer.serverLevel(),
                                        pos,
                                        state
                                )
                ) {
                    return true;
                }

                ProfessionToolManager.damageTool(
                        stack,
                        1
                );
            }

            return true;
        }

        @Override
        public boolean hurtEnemy(
                ItemStack stack,
                LivingEntity target,
                LivingEntity attacker
        ) {

            if (!attacker.level().isClientSide) {
                ProfessionToolManager.damageTool(
                        stack,
                        1
                );
            }

            // Custom profession durability is handled above. Returning false prevents
            // vanilla combat durability from pushing the stack past max damage and
            // deleting it instead of leaving it broken-but-repairable.
            return false;
        }

        @Override
        public boolean isEnchantable(
                ItemStack stack
        ) {

            return false;
        }

        @Override
        public Item getPolymerItem(
                ItemStack stack,
                ServerPlayer player
        ) {

            return baseItem;
        }
    }

    public static class CustomHoeItem extends HoeItem implements PolymerItem {

        private final Item baseItem;

        public CustomHoeItem(
                Item baseItem,
                Tier tier,
                Properties properties
        ) {

            super(
                    tier,
                    properties
            );

            this.baseItem =
                    baseItem;
        }

        @Override
        public float getDestroySpeed(
                ItemStack stack,
                BlockState state
        ) {

            return ProfessionToolManager.applyMiningSpeedStat(
                    stack,
                    super.getDestroySpeed(
                            stack,
                            state
                    )
            );
        }

        @Override
        public boolean mineBlock(
                ItemStack stack,
                Level level,
                BlockState state,
                BlockPos pos,
                LivingEntity miningEntity
        ) {

            if (!level.isClientSide && state.getDestroySpeed(level, pos) != 0.0F) {
                ProfessionToolManager.damageTool(
                        stack,
                        1
                );
            }

            return true;
        }

        @Override
        public boolean hurtEnemy(
                ItemStack stack,
                LivingEntity target,
                LivingEntity attacker
        ) {

            if (!attacker.level().isClientSide) {
                ProfessionToolManager.damageTool(
                        stack,
                        1
                );
            }

            // Custom profession durability is handled above. Returning false prevents
            // vanilla combat durability from pushing the stack past max damage and
            // deleting it instead of leaving it broken-but-repairable.
            return false;
        }

        @Override
        public boolean isEnchantable(
                ItemStack stack
        ) {

            return false;
        }

        @Override
        public Item getPolymerItem(
                ItemStack stack,
                ServerPlayer player
        ) {

            return baseItem;
        }
    }


    public static class CustomShovelItem extends ShovelItem implements PolymerItem {

        private final Item baseItem;

        public CustomShovelItem(
                Item baseItem,
                Tier tier,
                Properties properties
        ) {

            super(
                    tier,
                    properties
            );

            this.baseItem =
                    baseItem;
        }

        @Override
        public float getDestroySpeed(
                ItemStack stack,
                BlockState state
        ) {

            return ProfessionToolManager.applyMiningSpeedStat(
                    stack,
                    super.getDestroySpeed(
                            stack,
                            state
                    )
            );
        }

        @Override
        public boolean mineBlock(
                ItemStack stack,
                Level level,
                BlockState state,
                BlockPos pos,
                LivingEntity miningEntity
        ) {

            if (!level.isClientSide && state.getDestroySpeed(level, pos) != 0.0F) {
                if (
                        miningEntity instanceof ServerPlayer serverPlayer &&
                                DurabilitySavePassive.shouldPreserveDurability(
                                        serverPlayer,
                                        stack,
                                        serverPlayer.serverLevel(),
                                        pos,
                                        state
                                )
                ) {
                    return true;
                }

                ProfessionToolManager.damageTool(
                        stack,
                        1
                );
            }

            return true;
        }

        @Override
        public boolean hurtEnemy(
                ItemStack stack,
                LivingEntity target,
                LivingEntity attacker
        ) {

            if (!attacker.level().isClientSide) {
                ProfessionToolManager.damageTool(
                        stack,
                        1
                );
            }

            return false;
        }

        @Override
        public boolean isEnchantable(
                ItemStack stack
        ) {

            return false;
        }

        @Override
        public Item getPolymerItem(
                ItemStack stack,
                ServerPlayer player
        ) {

            return baseItem;
        }
    }

    public static class CustomSwordItem extends SwordItem implements PolymerItem {

        private final Item baseItem;

        public CustomSwordItem(
                Item baseItem,
                Tier tier,
                Properties properties
        ) {

            super(
                    tier,
                    properties
            );

            this.baseItem =
                    baseItem;
        }

        @Override
        public boolean hurtEnemy(
                ItemStack stack,
                LivingEntity target,
                LivingEntity attacker
        ) {

            if (!attacker.level().isClientSide) {
                ProfessionToolManager.damageTool(
                        stack,
                        1
                );
            }

            // Custom profession durability is handled above. Returning false prevents
            // vanilla combat durability from pushing the stack past max damage and
            // deleting it instead of leaving it broken-but-repairable.
            return false;
        }

        @Override
        public boolean isEnchantable(
                ItemStack stack
        ) {

            return false;
        }

        @Override
        public Item getPolymerItem(
                ItemStack stack,
                ServerPlayer player
        ) {

            return baseItem;
        }
    }

    public static class CustomGenericToolItem extends Item implements PolymerItem {

        private final Item baseItem;

        public CustomGenericToolItem(
                Item baseItem,
                Properties properties
        ) {

            super(
                    properties
            );

            this.baseItem =
                    baseItem;
        }

        @Override
        public boolean isEnchantable(
                ItemStack stack
        ) {

            return false;
        }

        @Override
        public Item getPolymerItem(
                ItemStack stack,
                ServerPlayer player
        ) {

            return baseItem;
        }
    }
}