package com.champutils.profession;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class ProfessionRewardPassiveConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Random RANDOM = new Random();

    public static Map<String, List<RewardEntry>> TABLES = new LinkedHashMap<>();

    private static final List<String> SHARD_RARITY_ORDER = List.of(
            "COMMON",
            "UNCOMMON",
            "RARE",
            "EPIC",
            "LEGENDARY"
    );

    public static class Root {
        public Map<String, List<RewardEntry>> tables = new LinkedHashMap<>();
    }

    public static class RewardEntry {
        public String item = "minecraft:air";
        public String type = "item";
        public String keyId = "";
        public String fragmentRarity = "";
        public int min = 1;
        public int max = 1;
        public int weight = 1;
        public boolean enabled = true;

        /**
         * Optional extra entry-level chance. This is checked after the entry wins
         * the weighted roll. Use this for ultra-rare digital keys/fragments without
         * making the whole table unreadable.
         */
        public double chancePercent = 100.0D;
        public double chancePerProfessionLevel = 0.0D;
    }

    public static void load() {
        try {
            File dir = new File("config/champutils");
            if (!dir.exists()) {
                dir.mkdirs();
            }

            File file = new File(dir, "profession_reward_passives.json");
            if (!file.exists()) {
                createDefault(file);
            }

            TABLES = readTables(file);
            filterSeedSaverTable();
            mergeMissingDefaultRewardEntries();
            filterSeedSaverTable();
        } catch (Exception e) {
            e.printStackTrace();
            TABLES = new LinkedHashMap<>();
        }
    }

    private static void filterSeedSaverTable() {
        List<RewardEntry> entries = TABLES.get("farming_seed_saver");
        if (entries == null) return;
        java.util.Set<String> allowed = java.util.Set.of(
                "cobblemon:roseli_berry", "cobblemon:chilan_berry", "cobblemon:babiri_berry", "cobblemon:colbur_berry",
                "cobblemon:haban_berry", "cobblemon:kasib_berry", "cobblemon:charti_berry", "cobblemon:tanga_berry",
                "cobblemon:payapa_berry", "cobblemon:coba_berry", "cobblemon:shuca_berry", "cobblemon:kebia_berry",
                "cobblemon:chople_berry", "cobblemon:yache_berry", "cobblemon:rindo_berry", "cobblemon:wacan_berry",
                "cobblemon:passho_berry", "cobblemon:occa_berry", "cobblemon:pinap_berry", "cobblemon:wepear_berry",
                "cobblemon:nanab_berry", "cobblemon:bluk_berry", "cobblemon:razz_berry", "cobblemon:persim_berry",
                "cobblemon:aspear_berry", "cobblemon:rawst_berry", "cobblemon:pecha_berry", "cobblemon:chesto_berry",
                "cobblemon:cheri_berry", "cobblemon:oran_berry"
        );
        entries.removeIf(entry -> entry == null || entry.item == null || !allowed.contains(entry.item.toLowerCase(java.util.Locale.ROOT)));
    }

    public static ItemStack rollReward(String tableId) {
        return roll(tableId);
    }

    public static ItemStack roll(String tableId) {
        return rollReward(tableId, null, null, null);
    }

    public static ItemStack rollReward(
            String tableId,
            ServerPlayer player,
            ProfessionType profession,
            ItemStack tool
    ) {
        if (TABLES == null || TABLES.isEmpty()) {
            load();
        }

        List<RewardEntry> entries = TABLES.get(tableId);
        if (entries == null || entries.isEmpty()) {
            return ItemStack.EMPTY;
        }

        int totalWeight = 0;
        for (RewardEntry entry : entries) {
            if (entry != null && entry.enabled) {
                totalWeight += Math.max(0, entry.weight);
            }
        }

        if (totalWeight <= 0) {
            return ItemStack.EMPTY;
        }

        int roll = RANDOM.nextInt(totalWeight);
        int cursor = 0;

        for (RewardEntry entry : entries) {
            if (entry == null || !entry.enabled) {
                continue;
            }

            cursor += Math.max(0, entry.weight);
            if (roll < cursor) {
                if (!passesEntryChance(entry, player, profession)) {
                    return ItemStack.EMPTY;
                }
                return createStack(entry, player, profession, tool);
            }
        }

        return ItemStack.EMPTY;
    }

    public static void giveRolled(ServerPlayer player, String tableId) {
        giveRolled(player, tableId, null, null, inferProfession(tableId), player == null ? ItemStack.EMPTY : player.getMainHandItem());
    }

    public static void giveRolled(
            ServerPlayer player,
            String tableId,
            String title,
            String subtitlePrefix
    ) {
        giveRolled(player, tableId, title, subtitlePrefix, inferProfession(tableId), player == null ? ItemStack.EMPTY : player.getMainHandItem());
    }

    public static void giveRolled(
            ServerPlayer player,
            String tableId,
            String title,
            String subtitlePrefix,
            ProfessionType profession,
            ItemStack tool
    ) {
        if (player == null) {
            return;
        }

        ItemStack reward = rollReward(tableId, player, profession, tool);
        if (reward.isEmpty() || reward.getItem() == Items.AIR) {
            return;
        }

        ItemStack displayStack = reward.copy();
        String rewardName = displayStack.getHoverName().getString();
        int count = displayStack.getCount();

        ItemStack toGive = reward.copy();
        if (!player.getInventory().add(toGive)) {
            player.drop(toGive, false);
        }

        if (ProfessionNotificationSettings.areProfessionPopupsEnabled(player)) {
            player.displayClientMessage(
                    Component.literal("§6Found §e" + count + "x " + rewardName),
                    true
            );
        }

        if (title != null && !title.isBlank()) {
            String prefix = subtitlePrefix == null || subtitlePrefix.isBlank()
                    ? "§fFound "
                    : subtitlePrefix;

            ProfessionSpecialCelebration.celebrateSpecialActive(
                    player,
                    title,
                    prefix + count + "x " + rewardName
            );
        }
    }

    private static boolean passesEntryChance(
            RewardEntry entry,
            ServerPlayer player,
            ProfessionType profession
    ) {
        double chance = entry.chancePercent;

        if (player != null && profession != null && entry.chancePerProfessionLevel != 0.0D) {
            int level = Math.max(1, ProfessionManager.getLevel(player, profession));
            chance += level * entry.chancePerProfessionLevel;
        }

        chance = Math.max(0.0D, Math.min(100.0D, chance));
        return chance >= 100.0D || RANDOM.nextDouble() * 100.0D < chance;
    }

    private static Map<String, List<RewardEntry>> readTables(File file) throws Exception {
        Map<String, List<RewardEntry>> loaded = new LinkedHashMap<>();

        try (FileReader reader = new FileReader(file)) {
            JsonElement rootElement = JsonParser.parseReader(reader);
            if (rootElement == null || !rootElement.isJsonObject()) {
                return loaded;
            }

            JsonObject root = rootElement.getAsJsonObject();

            if (root.has("tables") && root.get("tables").isJsonObject()) {
                readTableObject(root.getAsJsonObject("tables"), loaded);
            }

            readTableObject(root, loaded);
        }

        return loaded;
    }

    private static void readTableObject(JsonObject object, Map<String, List<RewardEntry>> output) {
        for (Map.Entry<String, JsonElement> entry : object.entrySet()) {
            String tableName = entry.getKey();
            JsonElement value = entry.getValue();

            if ("tables".equals(tableName)) {
                continue;
            }

            JsonArray array = null;

            if (value != null && value.isJsonArray()) {
                array = value.getAsJsonArray();
            } else if (value != null && value.isJsonObject()) {
                JsonObject tableObject = value.getAsJsonObject();
                if (tableObject.has("rewards") && tableObject.get("rewards").isJsonArray()) {
                    array = tableObject.getAsJsonArray("rewards");
                }
            }

            if (array == null) {
                continue;
            }

            List<RewardEntry> rewards = new ArrayList<>();

            for (JsonElement rewardElement : array) {
                if (rewardElement == null || !rewardElement.isJsonObject()) {
                    continue;
                }

                RewardEntry reward = GSON.fromJson(rewardElement, RewardEntry.class);
                if (reward != null) {
                    rewards.add(reward);
                }
            }

            output.put(tableName, rewards);
        }
    }

    private static ItemStack createStack(
            RewardEntry entry,
            ServerPlayer player,
            ProfessionType profession,
            ItemStack tool
    ) {
        if (entry == null) {
            return ItemStack.EMPTY;
        }

        String type = entry.type == null || entry.type.isBlank()
                ? "item"
                : entry.type.trim().toLowerCase();

        int min = Math.max(1, entry.min);
        int max = Math.max(min, entry.max);
        int amount = min + RANDOM.nextInt(max - min + 1);

        if ("profession_fragment".equals(type)) {
            String rarity = entry.fragmentRarity == null || entry.fragmentRarity.isBlank()
                    ? "COMMON"
                    : entry.fragmentRarity.trim().toUpperCase();
            if ("MYTHIC".equals(rarity)) {
                rarity = "LEGENDARY";
            }
            return ProfessionFragmentManager.createFragmentStack(rarity, amount);
        }

        if ("profession_fragment_gamble".equals(type) || "fragment_gamble".equals(type)) {
            String rarity = rollAllowedFragmentRarity(player, profession);
            if (rarity == null || rarity.isBlank()) {
                return ItemStack.EMPTY;
            }
            return ProfessionFragmentManager.createFragmentStack(rarity, amount);
        }

        return createItemStack(entry, amount);
    }

    private static ItemStack createItemStack(RewardEntry entry, int amount) {
        if (entry.item == null || entry.item.isBlank()) {
            return ItemStack.EMPTY;
        }

        try {
            Item item = BuiltInRegistries.ITEM.get(ResourceLocation.parse(entry.item));
            if (item == null || item == Items.AIR) {
                return ItemStack.EMPTY;
            }

            return new ItemStack(item, amount);
        } catch (Exception ignored) {
            return ItemStack.EMPTY;
        }
    }

    /**
     * Profession fragment passive drops are based on profession level, not tool rarity:
     * - Level 0-9: COMMON only
     * - Level 10-19: UNCOMMON and below
     * - Level 20-29: RARE and below
     * - Level 30-49: EPIC and below
     * - Level 50+: LEGENDARY and below
     * Mythic fragments are never produced by profession passive drops.
     */
    private static String rollAllowedFragmentRarity(ServerPlayer player, ProfessionType profession) {
        int level = player == null || profession == null
                ? 0
                : Math.max(0, ProfessionManager.getLevel(player, profession));

        int maxIndex;
        if (level >= 50) {
            maxIndex = 4;
        } else if (level >= 30) {
            maxIndex = 3;
        } else if (level >= 20) {
            maxIndex = 2;
        } else if (level >= 10) {
            maxIndex = 1;
        } else {
            maxIndex = 0;
        }

        maxIndex = Math.max(0, Math.min(maxIndex, SHARD_RARITY_ORDER.size() - 1));
        return SHARD_RARITY_ORDER.get(RANDOM.nextInt(maxIndex + 1));
    }

    private static void mergeMissingDefaultRewardEntries() {
        addMissingEntry("forestry_seed_finder", entry("cobblemon:red_apricorn_seed", 1, 2, 8));
        addMissingEntry("forestry_seed_finder", entry("cobblemon:blue_apricorn_seed", 1, 2, 8));
        addMissingEntry("forestry_seed_finder", entry("cobblemon:green_apricorn_seed", 1, 2, 8));
        addMissingEntry("forestry_seed_finder", entry("cobblemon:yellow_apricorn_seed", 1, 2, 8));
        addMissingEntry("forestry_seed_finder", entry("cobblemon:black_apricorn_seed", 1, 2, 5));
        addMissingEntry("forestry_seed_finder", entry("cobblemon:white_apricorn_seed", 1, 2, 5));
        addMissingEntry("forestry_seed_finder", entry("cobblemon:pink_apricorn_seed", 1, 2, 5));

        addMissingEntry("farming_seed_saver", entry("minecraft:chicken_spawn_egg", 1, 1, 5));
        addMissingEntry("farming_seed_saver", entry("minecraft:cow_spawn_egg", 1, 1, 4));
        addMissingEntry("farming_seed_saver", entry("minecraft:pig_spawn_egg", 1, 1, 4));
        addMissingEntry("farming_seed_saver", entry("minecraft:sheep_spawn_egg", 1, 1, 4));
        addMissingEntry("farming_seed_saver", entry("minecraft:rabbit_spawn_egg", 1, 1, 3));
        addMissingEntry("farming_seed_saver", entry("minecraft:villager_spawn_egg", 1, 1, 1));
        addMissingEntry("farming_seed_saver", entry("cobblemon:aguav_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:apicot_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:aspear_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:babiri_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:belue_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:bluk_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:charti_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:cheri_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:chesto_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:chilan_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:chople_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:coba_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:colbur_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:cornn_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:custap_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:durin_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:enigma_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:figy_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:ganlon_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:grepa_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:haban_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:hondew_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:hopo_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:iapapa_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:jaboca_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:kasib_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:kebia_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:kee_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:kelpsy_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:lansat_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:leppa_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:liechi_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:lum_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:mago_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:magost_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:maranga_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:micle_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:nanab_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:nomel_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:occa_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:oran_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:pamtre_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:passho_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:payapa_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:pecha_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:persim_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:petaya_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:pinap_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:pomeg_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:qualot_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:rabuta_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:rawst_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:razz_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:rindo_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:roseli_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:rowap_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:salac_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:shuca_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:sitrus_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:spelon_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:starf_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:tamato_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:tanga_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:touga_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:wacan_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:watmel_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:wepear_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:wiki_berry", 1, 2, 3));
        addMissingEntry("farming_seed_saver", entry("cobblemon:yache_berry", 1, 2, 3));
    }

    private static void addMissingEntry(String tableId, RewardEntry reward) {
        if (tableId == null || reward == null) {
            return;
        }

        List<RewardEntry> rewards = TABLES.computeIfAbsent(tableId, ignored -> new ArrayList<>());
        for (RewardEntry existing : rewards) {
            if (sameReward(existing, reward)) {
                return;
            }
        }
        rewards.add(reward);
    }

    private static boolean sameReward(RewardEntry first, RewardEntry second) {
        if (first == null || second == null) {
            return false;
        }

        String firstType = first.type == null ? "item" : first.type;
        String secondType = second.type == null ? "item" : second.type;
        if (!firstType.equalsIgnoreCase(secondType)) {
            return false;
        }

        if ("item".equalsIgnoreCase(firstType)) {
            String firstItem = first.item == null ? "" : first.item;
            String secondItem = second.item == null ? "" : second.item;
            return firstItem.equalsIgnoreCase(secondItem);
        }

        String firstKey = first.keyId == null ? "" : first.keyId;
        String secondKey = second.keyId == null ? "" : second.keyId;
        String firstRarity = first.fragmentRarity == null ? "" : first.fragmentRarity;
        String secondRarity = second.fragmentRarity == null ? "" : second.fragmentRarity;
        return firstKey.equalsIgnoreCase(secondKey) && firstRarity.equalsIgnoreCase(secondRarity);
    }

    private static ProfessionType inferProfession(String tableId) {
        if (tableId == null) {
            return null;
        }

        String normalized = tableId.toLowerCase();
        if (normalized.startsWith("forestry")) {
            return ProfessionType.FORESTRY;
        }
        if (normalized.startsWith("farming")) {
            return ProfessionType.FARMING;
        }
        if (normalized.contains("treasure") || normalized.contains("shard") || normalized.contains("gem")) {
            return ProfessionType.MINING;
        }
        return null;
    }

    private static void createDefault(File file) throws Exception {
        Root root = new Root();

        root.tables.put("treasurePing", list(
                entry("minecraft:raw_iron", 3, 8, 28),
                entry("minecraft:raw_copper", 6, 14, 26),
                entry("minecraft:raw_gold", 2, 5, 18),
                entry("minecraft:lapis_lazuli", 4, 10, 12),
                entry("minecraft:redstone", 4, 12, 10),
                entry("minecraft:diamond", 1, 2, 4),
                entry("minecraft:emerald", 1, 2, 2),
                entry("cobblemon:hard_stone", 1, 1, 2),
                entry("cobblemon:soft_sand", 1, 1, 2),
                entry("cobblemon:ancient_relic_copper", 1, 1, 1)
        ));

        root.tables.put("shardFinder", list(
                entry("cobblemon:fire_stone", 1, 1, 14),
                entry("cobblemon:water_stone", 1, 1, 14),
                entry("cobblemon:thunder_stone", 1, 1, 14),
                entry("cobblemon:leaf_stone", 1, 1, 14),
                entry("cobblemon:ice_stone", 1, 1, 12),
                entry("cobblemon:moon_stone", 1, 1, 6),
                entry("cobblemon:sun_stone", 1, 1, 6),
                entry("cobblemon:dawn_stone", 1, 1, 5),
                entry("cobblemon:dusk_stone", 1, 1, 5),
                entry("cobblemon:shiny_stone", 1, 1, 4),
                fragmentGambleEntry(1, 1, 1, 0.05D, 0.003D)
        ));

        root.tables.put("gemFinder", list(
                entry("minecraft:diamond", 1, 1, 50),
                entry("minecraft:emerald", 1, 1, 25),
                entry("cobblemon:hard_stone", 1, 1, 8),
                entry("cobblemon:light_clay", 1, 1, 4),
                entry("cobblemon:metal_coat", 1, 1, 3),
                fragmentGambleEntry(1, 1, 1, 0.04D, 0.0025D)
        ));

        root.tables.put("forestry_sap_finder", list(
                entry("minecraft:apple", 1, 3, 36),
                entry("cobblemon:miracle_seed", 1, 1, 8),
                entry("cobblemon:big_root", 1, 1, 6),
                entry("cobblemon:absorb_bulb", 1, 1, 4),
                entry("cobblemon:silver_powder", 1, 1, 4),
                entry("cobblemon:grassy_seed", 1, 1, 2),
                fragmentGambleEntry(1, 1, 1, 0.04D, 0.0025D)
        ));

        root.tables.put("forestry_seed_finder", list(
                entry("minecraft:oak_sapling", 1, 2, 20),
                entry("minecraft:spruce_sapling", 1, 2, 18),
                entry("minecraft:cherry_sapling", 1, 1, 8),
                entry("minecraft:cocoa_beans", 1, 3, 12),
                entry("cobblemon:red_apricorn_seed", 1, 2, 8),
                entry("cobblemon:blue_apricorn_seed", 1, 2, 8),
                entry("cobblemon:green_apricorn_seed", 1, 2, 8),
                entry("cobblemon:yellow_apricorn_seed", 1, 2, 8),
                entry("cobblemon:black_apricorn_seed", 1, 2, 5),
                entry("cobblemon:white_apricorn_seed", 1, 2, 5),
                entry("cobblemon:pink_apricorn_seed", 1, 2, 5),
                entry("cobblemon:red_apricorn", 1, 2, 4),
                entry("cobblemon:blue_apricorn", 1, 2, 4),
                entry("cobblemon:green_apricorn", 1, 2, 4),
                entry("cobblemon:yellow_apricorn", 1, 2, 4),
                entry("cobblemon:revival_herb", 1, 1, 2),
                fragmentGambleEntry(1, 1, 1, 0.04D, 0.0025D)
        ));

        root.tables.put("farming_seed_saver", list(
                entry("minecraft:wheat_seeds", 1, 3, 24),
                entry("minecraft:pumpkin_seeds", 1, 2, 10),
                entry("minecraft:melon_seeds", 1, 2, 10),
                entry("minecraft:beetroot_seeds", 1, 2, 8),
                entry("minecraft:chicken_spawn_egg", 1, 1, 5),
                entry("minecraft:cow_spawn_egg", 1, 1, 4),
                entry("minecraft:pig_spawn_egg", 1, 1, 4),
                entry("minecraft:sheep_spawn_egg", 1, 1, 4),
                entry("minecraft:rabbit_spawn_egg", 1, 1, 3),
                entry("minecraft:villager_spawn_egg", 1, 1, 1),
                entry("cobblemon:oran_berry", 1, 3, 12),
                entry("cobblemon:leppa_berry", 1, 2, 8),
                entry("cobblemon:pecha_berry", 1, 2, 8),
                entry("cobblemon:cheri_berry", 1, 2, 8),
                entry("cobblemon:aguav_berry", 1, 2, 3),
                entry("cobblemon:apicot_berry", 1, 2, 3),
                entry("cobblemon:aspear_berry", 1, 2, 3),
                entry("cobblemon:babiri_berry", 1, 2, 3),
                entry("cobblemon:belue_berry", 1, 2, 3),
                entry("cobblemon:bluk_berry", 1, 2, 3),
                entry("cobblemon:charti_berry", 1, 2, 3),
                entry("cobblemon:chesto_berry", 1, 2, 3),
                entry("cobblemon:chilan_berry", 1, 2, 3),
                entry("cobblemon:chople_berry", 1, 2, 3),
                entry("cobblemon:coba_berry", 1, 2, 3),
                entry("cobblemon:colbur_berry", 1, 2, 3),
                entry("cobblemon:cornn_berry", 1, 2, 3),
                entry("cobblemon:custap_berry", 1, 2, 3),
                entry("cobblemon:durin_berry", 1, 2, 3),
                entry("cobblemon:enigma_berry", 1, 2, 3),
                entry("cobblemon:figy_berry", 1, 2, 3),
                entry("cobblemon:ganlon_berry", 1, 2, 3),
                entry("cobblemon:grepa_berry", 1, 2, 3),
                entry("cobblemon:haban_berry", 1, 2, 3),
                entry("cobblemon:hondew_berry", 1, 2, 3),
                entry("cobblemon:hopo_berry", 1, 2, 3),
                entry("cobblemon:iapapa_berry", 1, 2, 3),
                entry("cobblemon:jaboca_berry", 1, 2, 3),
                entry("cobblemon:kasib_berry", 1, 2, 3),
                entry("cobblemon:kebia_berry", 1, 2, 3),
                entry("cobblemon:kee_berry", 1, 2, 3),
                entry("cobblemon:kelpsy_berry", 1, 2, 3),
                entry("cobblemon:lansat_berry", 1, 2, 3),
                entry("cobblemon:liechi_berry", 1, 2, 3),
                entry("cobblemon:lum_berry", 1, 2, 3),
                entry("cobblemon:mago_berry", 1, 2, 3),
                entry("cobblemon:magost_berry", 1, 2, 3),
                entry("cobblemon:maranga_berry", 1, 2, 3),
                entry("cobblemon:micle_berry", 1, 2, 3),
                entry("cobblemon:nanab_berry", 1, 2, 3),
                entry("cobblemon:nomel_berry", 1, 2, 3),
                entry("cobblemon:occa_berry", 1, 2, 3),
                entry("cobblemon:pamtre_berry", 1, 2, 3),
                entry("cobblemon:passho_berry", 1, 2, 3),
                entry("cobblemon:payapa_berry", 1, 2, 3),
                entry("cobblemon:persim_berry", 1, 2, 3),
                entry("cobblemon:petaya_berry", 1, 2, 3),
                entry("cobblemon:pinap_berry", 1, 2, 3),
                entry("cobblemon:pomeg_berry", 1, 2, 3),
                entry("cobblemon:qualot_berry", 1, 2, 3),
                entry("cobblemon:rabuta_berry", 1, 2, 3),
                entry("cobblemon:rawst_berry", 1, 2, 3),
                entry("cobblemon:razz_berry", 1, 2, 3),
                entry("cobblemon:rindo_berry", 1, 2, 3),
                entry("cobblemon:roseli_berry", 1, 2, 3),
                entry("cobblemon:rowap_berry", 1, 2, 3),
                entry("cobblemon:salac_berry", 1, 2, 3),
                entry("cobblemon:shuca_berry", 1, 2, 3),
                entry("cobblemon:sitrus_berry", 1, 2, 3),
                entry("cobblemon:spelon_berry", 1, 2, 3),
                entry("cobblemon:starf_berry", 1, 2, 3),
                entry("cobblemon:tamato_berry", 1, 2, 3),
                entry("cobblemon:tanga_berry", 1, 2, 3),
                entry("cobblemon:touga_berry", 1, 2, 3),
                entry("cobblemon:wacan_berry", 1, 2, 3),
                entry("cobblemon:watmel_berry", 1, 2, 3),
                entry("cobblemon:wepear_berry", 1, 2, 3),
                entry("cobblemon:wiki_berry", 1, 2, 3),
                entry("cobblemon:yache_berry", 1, 2, 3),
                entry("cobblemon:revival_herb", 1, 1, 2),
                fragmentGambleEntry(1, 1, 1, 0.04D, 0.0025D)
        ));

        root.tables.put("farming_golden_harvest", list(
                entry("minecraft:golden_carrot", 1, 2, 28),
                entry("minecraft:golden_apple", 1, 1, 4),
                entry("cobblemon:oran_berry", 1, 3, 16),
                entry("cobblemon:sitrus_berry", 1, 2, 8),
                entry("cobblemon:lum_berry", 1, 1, 4),
                entry("cobblemon:liechi_berry", 1, 1, 2),
                fragmentGambleEntry(1, 1, 1, 0.05D, 0.003D)
        ));

        try (FileWriter writer = new FileWriter(file)) {
            GSON.toJson(root, writer);
        }
    }

    private static List<RewardEntry> list(RewardEntry... entries) {
        List<RewardEntry> list = new ArrayList<>();
        for (RewardEntry entry : entries) {
            list.add(entry);
        }
        return list;
    }

    private static RewardEntry entry(String item, int min, int max, int weight) {
        RewardEntry entry = new RewardEntry();
        entry.item = item;
        entry.min = min;
        entry.max = max;
        entry.weight = weight;
        return entry;
    }

    private static RewardEntry fragmentGambleEntry(int min, int max, int weight, double chance, double chancePerLevel) {
        RewardEntry entry = new RewardEntry();
        entry.type = "profession_fragment_gamble";
        entry.min = min;
        entry.max = max;
        entry.weight = weight;
        entry.chancePercent = chance;
        entry.chancePerProfessionLevel = chancePerLevel;
        return entry;
    }
}
